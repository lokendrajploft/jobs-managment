<?php

if (!defined('ABSPATH')) {
    exit;
}

class jplf_Job_Board_Deactivation
{

    public function deactivated()
    {

    }
}

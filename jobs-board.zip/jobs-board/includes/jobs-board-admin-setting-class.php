<?php if (!defined('ABSPATH')) {
    exit;
    /*accessed directly */
}

class jobs_board_setting_admin_init {

	public function __construct()
    {

       require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-jobs-board-settings-general.php';

        // Check if General Settings Class Exists
        if (class_exists('Jobs_Board_Settings_General')) {
           // Initialize General Settings class           
            new Jobs_Board_Settings_General();
        }
        

    }

}

 ?>
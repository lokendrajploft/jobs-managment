<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('jplf_jobs_board_posts_shortcode')) {
    function jplf_jobs_board_posts_shortcode($atts)
    {
    wp_enqueue_script('custom-ajax-js', plugins_url('../assets/js/custom-ajax.js', __FILE__), array('jquery'));
        $atts = shortcode_atts(array(
            'per_page' => 10,
            'order'    => 'DESC',
            'orderby'  => 'date',
        ), $atts);

        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        $args = array(
            'post_type'      => 'jobs',
            'posts_per_page' => $atts["per_page"],
            'order'          => $atts["order"],
            'orderby'        => $atts["orderby"],
            'paged'          => $paged,
        );

        $query = new WP_Query($args);

        $i = 0;

        if ($query->have_posts()): $output;

        

            while ($query->have_posts()): $query->the_post();

                $output .= '<div id="post-' . get_the_ID() . '" class="' . implode(' ', get_post_class()) . ' ">';
                $output .= '<div class="jobsboard_list_innerpart">';
                $output .= '<div class="row equal">';

                $output .= '<div class="col-md-12">';

                //$output .= '<a href="' . get_permalink() . '" title="' . the_title('', '', false) . '">';

                $output .= '<h2 class="post-title"><span><a href="' . get_permalink() . '" title="' . the_title('', '', false) . '">' . the_title('', '', false) . '</a></span></h2>';

                $output .= '<div class="company-information">';
                $output .= '<ul>';
                $output .= '<li>';
                if (!empty(get_post_meta(get_the_id(), "jobs_board_company_name", true))) {

                    if (get_post_meta(get_the_id(), "jobs_board_company_logo", true)) {

                        $cmpnylogo = get_post_meta(get_the_id(), "jobs_board_company_logo", true);
                    } else {

                        $cmpnylogo = plugins_url('../images/not-available.png', __FILE__);

                    }

                    $output .= '<span><img src="' . $cmpnylogo . '" class="company_logo"> ' . get_post_meta(get_the_id(), "jobs_board_company_name", true) . '</span>';
                }

                $output .= '</li>';
                $output .= '<li>';

                if (!empty(get_post_meta(get_the_id(), "jobs_board_company_email_address", true))) {
                    $output .= '<span><img src="' . plugins_url('../images/hr-mail-icon.png', __FILE__) . '" class="company_logo"> <a href="mailto:' . get_post_meta(get_the_id(), "jobs_board_company_email_address", true) . '">' . get_post_meta(get_the_id(), "jobs_board_company_email_address", true) . ' </a></span>';
                }
                $output .= '</li>';

                $output .= '<li>';

                if (!empty(get_post_meta(get_the_id(), "jobs_board_company_email_address", true))) {
                    $output .= '<span><img src="' . plugins_url('../images/logo-website-icon.jpg', __FILE__) . '" class="company_logo"> <a href="' . get_post_meta(get_the_id(), "jobs_board_company_website", true) . '">' . get_post_meta(get_the_id(), "jobs_board_company_website", true) . ' </a></span>';
                }
                $output .= '</li>';
                $output .= '</ul>';
                $output .= '</div>';

                $output .= '</div>';

                $output .= '<div class="col-md-3 col-sm-4 col-xs-6">';

                if (has_post_thumbnail()) {

                $output .= get_the_post_thumbnail(get_the_id(), 'featured', array('class' => 'img-responsive aligncenter'));

                } else {

                    $output .= '<img class="img-responsive aligncenter" src="' . plugins_url('/images/not-available.png', __FILE__) . '" alt="Not Available" height="150" width="200" />';

                }

                $output .= '</a>';

                $output .= '</div>';

                $output .= '<div class="col-md-9 short_description_jobsboard">';

                $output .= get_the_excerpt();

                if (!empty(get_the_excerpt())) {

                    $output .= '...<span class="post-permalink"><a href="' . get_permalink() . '" title="' . the_title('', '', false) . '">Read More</a></span>';

                }

                $output .= '<div class="jops-additional-details">';

                $output .= '<div class="post-info jobs-post-term-info">';

                $output .= '<ol>';

                $output .= '<li> Job Posted: ' . get_the_time("F j, Y") . '</li>';

                $output .= '<li>By: ' . get_the_author() . '</li>';

                $output .= '<li> Job Categories: ' . get_the_term_list(get_the_id(), 'job Category', '', ', ') . '</li>';

                $output .= '<li> Job Types: ' . get_the_term_list(get_the_id(), 'Job Types', '', ', ') . '</li>';

                $output .= '<li> Job Locations: ' . get_the_term_list(get_the_id(), 'Job Location', '', ', ') . '</li>';

                $output .= '</ol>';

                $output .= '</div>';

                $output .= '</div>';

                $output .= '<button type="button" class="btn apply_jobs" data-jobid="jobid_' . get_the_id() . '"> Apply Now</button>';

                $output .= '
            <div id="jobid_' . get_the_id() . '" class="modal fade" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Apply for ' . get_the_title() . '</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                         <div class="alert alert-danger applied_already" role="alert" style="display:none;"></div>
                         <div class="alert alert-success success" role="alert" style="display:none;"></div>
                        <form action="" method="post" enctype="multipart/form-data" id="form_job_'. get_the_id() .'" class="applyjobs_form" >
                        <input type="hidden" name="jobs_board_id" class="form-control jobsid" value="' . get_the_ID() . '">
                        <input type="hidden" name="jobs_name" class="form-control" value="' . get_the_title() . '">
                        <div class="modal-body">
                            <div class="row equal">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>First Name*</label>
                                        <input type="text" name="first_name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Last Name</label>
                                        <input type="text" name="last_name" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row equal">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Email*</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Phone*</label>
                                        <input type="text" name="contact_no" class="form-control" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))"  required>
                                    </div>
                                </div>
                            </div>';
                            $output .=  '<div class="row equal">';
                            $output .=    '<div class="col-6">';
                            $output .=     '<div class="form-group">';
                            $output .=     '<label>Jobs Type</label>';

                                         $jobstypes = get_the_terms( get_the_id(), 'Job Types' );

                                         $output .= '<select class="form-control" name="jobs_type">';

                                         $output .= '<option value="">Select Jobs type</option>';
                                          foreach( $jobstypes as $jobstype){

                                         $output .= '<option value='. esc_html($jobstype->slug).'>'. $jobstype->name.'</option>';
                                        }
                                         $output .='</select>';

                                $output .='</div>';
                                $output .='</div>';

                                $output .= '<div class="col-6">
                                    <div class="form-group">
                                        <label>Jobs Category</label>';

                                         $jobcategories = get_the_terms( get_the_id(), 'job Category' );

                                         $output .= '<select class="form-control" name="jobs_category">';

                                         $output .= '<option value="">Select Jobs Category</option>';
                                          foreach( $jobcategories as $jobcate){

                                         $output .= '<option value='.esc_html($jobcate->slug).'>'. $jobcate->name.'</option>';
                                        }
                                         $output .='</select>';

                                $output .='</div>';
                                $output .='</div>';
                                $output .='</div>';


                            $output .=  '<div class="row equal">';
                            $output .=    '<div class="col-6">';
                            $output .=     '<div class="form-group">';
                            $output .=     '<label>Jobs location</label>';

                                         $jobslocations = get_the_terms( get_the_id(), 'Job Location' );

                                         $output .= '<select class="form-control" name="jobs_location">';

                                         $output .= '<option value="">Select Jobs location</option>';
                                          foreach( $jobslocations as $jobslocation){

                                         $output .= '<option value='. esc_html($jobslocation->slug).'>'. $jobslocation->name.'</option>';
                                        }
                                         $output .='</select>';

                                $output .='</div>';
                                $output .='</div>';

                                $output .= '<div class="col-6">
                                    <div class="form-group">
                                        <label>work experience (In year)</label>';

                                        
                                          $output .= '<select class="form-control" name="jobs_expirence">';
                                          $output .= '<option value="">Select experience</option>';
                                          $output .= '<option value="Fresher">Fresher</option>';
                                          $output .= '<option value="1">1</option>';
                                          $output .= '<option value="2">2</option>';
                                          $output .= '<option value="3">3</option>';
                                          $output .= '<option value="4">4</option>';
                                          $output .= '<option value="5">5</option>';
                                          $output .= '<option value="more then 5">more then 5</option>';
                                      
                                         $output .='</select>';

                                $output .='</div>';
                                $output .='</div>';
                                $output .='</div>';

                               $output .=  '<div class="row equal">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>Resume Upload*</label>
                                        <input type="file" name="resume" class="form-control resume_applicant" accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
                                    </div>
                                    <div class="alert alert-danger errorcv" role="alert" style="display:none;">
                                       </div>
                                </div                             
                                </div>';

                            $output .='
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>Comments</label>
                                        <textarea class="form-control" name="apply_short_description"></textarea>
                                    </div>
                                </div>
                            </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Apply Now</button>
                            
                        </div>
                        </form>
                    </div>
                </div>
            </div>';

                $output .= '</div>';

                $output .= '</div>';

                $output .= '</div>';

                $output .= '</div>';

                $i++;

            endwhile;

            global $wp_query;
            $args_pagi = array(
                'base'    => add_query_arg('paged', '%#%'),
                'total'   => $query->max_num_pages,
                'current' => $paged,
            );
            $output .= '<div class="post-nav">';
            $output .= paginate_links($args_pagi);

            //    $output .= '<div class="next-page">' . get_next_posts_link( "Older Entries »", 3 ) . '</div>';

            $output .= '</div>';

        else:

            $output .= '<p>Sorry, there are no jobs post to display</p>';

        endif; ?>

     <?php   wp_reset_postdata();

        return $output;
    }
}

add_shortcode('jobsboard-list', 'jplf_jobs_board_posts_shortcode');

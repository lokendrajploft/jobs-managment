<?php if (!defined('ABSPATH')) {exit;}

     // Options-> Notifications
        add_option('jobs_board_hr_notification', 'yes');
        add_option('jobs_board_applicant_notification', 'yes');
        add_option('jobs_board_admin_notification', 'yes');


 ?>
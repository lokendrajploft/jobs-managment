<?php if (!defined('ABSPATH')) { exit(); } 

if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );


class jobs_board_class_tabel extends WP_List_Table {

function getdata($per_page = 5, $page_number = 1){

      global $wpdb;
$sql = "SELECT * FROM {$wpdb->prefix}jobs_apply_user";


if ( ! empty( $_REQUEST['orderby'] ) ) {
$sql .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
$sql .= ! empty( $_REQUEST['order'] ) ? ' ' . esc_sql( $_REQUEST['order'] ) : ' ASC';
}

$sql .= " LIMIT $per_page";

$sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;

$result = $wpdb->get_results( $sql, 'ARRAY_A' );

return $result;

}

function get_columns(){
 $columns = [
        'cb' => '<input type="checkbox" />', 
        'first_name' => __('First Name', 'jobs-board') , 
        'last_name' => __('Last Name', 'jobs-board') , 
        'email' => __('Email address', 'jobs-board') , 
        'jobs_name' => __('jobs Name', 'jobs-board') , 
        'jobs_category' => __('Jobs Category', 'jobs-board') , 
        'jobs_locations' => __('Jobs Locations', 'jobs-board') , 
        'apply_expirence' => __('Jobs expirence', 'jobs-board') ,
        'created' => __('Date', 'jobs-board') 
];
  return $columns;
}

function prepare_items() {
 $this->_column_headers = $this->get_column_info();
 $this->process_bulk_action();

$per_page = $this->get_items_per_page( 'applicants_per_page', 5 );
$current_page = $this->get_pagenum();
$total_items = self::record_count();

$this->set_pagination_args( [
'total_items' => $total_items, //WE have to calculate the total number of items
'per_page' => $per_page //WE have to determine how many items to show on a page
] );

$this->items = self::get_applicants( $per_page, $current_page );

}

function column_default( $item, $column_name ) {
  switch( $column_name ) { 
    case 'ID':
    case 'user_login':
    case 'user_email':
      return $item[ $column_name ];
    default:
      return print_r( $item, true ) ; 
  }
}
}




function my_render_list_page(){
  $myListTable = new jobs_board_class_tabel();
  echo '<div class="wrap"><h2>My List Table Test</h2>'; 
  $myListTable->prepare_items(); 
  $myListTable->display(); 
  echo '</div>'; 
}


}
?>
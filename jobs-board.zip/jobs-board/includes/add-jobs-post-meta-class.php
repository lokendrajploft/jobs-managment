<?php
if (!defined('ABSPATH')) {exit;}

class jplf_jobs_board_post_meta
{

    /*add post meta options for jobs */

    public static function jobs_post_meta_output_field()
    {

        wp_nonce_field('jplf_jobs_board_meta_box', 'jplf_job_board_meta_box_nonce');

        echo '<div class="post_jobs-metabox">';

        jplf_jobs_board_post_meta::textfield('_company_name', esc_html__('Company Name', 'jobs-board'), '');

        jplf_jobs_board_post_meta::textfield('_company_website', esc_html__('Company Website', 'jobs-board'), '');
        jplf_jobs_board_post_meta::textfield('_company_address', esc_html__('Company address', 'jobs-board'), '');
       jplf_jobs_board_post_meta::textfield('_company_email_address', esc_html__('Email address', 'jobs-board'), '');
       jplf_jobs_board_post_meta::textfield('_company_tagline', esc_html__('Company Tagline', 'jobs-board'), '');
        jplf_jobs_board_post_meta::uploadlogo('_company_logo', esc_html__('Company Logo', 'jobs-board'), '');
        echo '</div>';

    }

    public static function textfield($id, $label, $desc = '')
    {

        global $post;
        $pmhtml = '<p class="post-metabox-field">';
        $pmhtml .= '<label for="jobs_board' . $id . '">' . $label . '</label>';
        $pmhtml .= '<input type="text" id="jobs_board' . $id . '" name="jobs_board' . $id . '" value="' . esc_attr(get_post_meta($post->ID, 'jobs_board' . $id, true)) . '" />';
        if ($desc) {
            $pmhtml .= '<span class="tips">' . $desc . '</span>';
        }

        $pmhtml .= '</p>';
        echo $pmhtml;
    }

    public static function uploadlogo($id, $label, $desc = '')
    {
        global $post;
        ?>

        <p class="metabox-field">
            <label for="jobs_board<?php echo $id; ?>"><?php echo $label; ?></label>
            <span class="file_url">
                <input type="text" name="jobs_board<?php echo $id; ?>" id="jobs_board<?php echo $id; ?>" class="upload_field" placeholder="URL to the company logo" value="<?php echo esc_url(get_post_meta($post->ID, 'jobs_board' . $id, true)); ?>" />
                <button type="button" class="button job-board-logo-button"><?php esc_html_e('Upload', 'jobs-board');?></button>
            </span>
            <?php if ($desc): ?>
                <p><?php echo $desc; ?></p>
            <?php endif;?>
        </p>

        <?php
}

    public static function jplf_save_jobsboard_meta($post_id)
    {
        $POST_data = filter_input_array(INPUT_POST);


        foreach ($POST_data as $key => $value) {
            if (strstr($key, 'jobs_board')) {
                update_post_meta($post_id, sanitize_key($key), $value);
            }
        }
    }

}

?>
<?php if (!defined('ABSPATH')) {die;}

function w4dev_ajaxurl_cdata_to_front(){ 
    ?>
    <script type="text/javascript"> 
        ajaxurl = '<?php echo admin_url( 'admin-ajax.php'); ?>';
     </script>
    <?php 
}
add_action( 'wp_head', 'w4dev_ajaxurl_cdata_to_front', 1 );

/*jobs board applicant employer using ajax form*/

add_action( 'wp_ajax_applicant_emp_form_action', 'applicant_emp_form_fun' );
add_action( 'wp_ajax_nopriv_applicant_emp_form_action', 'applicant_emp_form_fun' );


function applicant_emp_form_fun()
{
	global $wpdb;

    $tablejobs = $wpdb->prefix."jobs_apply_user";

    $email = $_POST['email'];

    $jobsid = $_POST['jobs_board_id'];

    $wpdb->get_results("SELECT * FROM $tablejobs WHERE email = '$email' AND jobs_board_id ='$jobsid'");


    $row_count = $wpdb->num_rows;


    if ($row_count >= 1) {

     echo 'applied';

    }else{

           require_once( ABSPATH . 'wp-admin/includes/image.php' );
           require_once( ABSPATH . 'wp-admin/includes/file.php' );
           require_once( ABSPATH . 'wp-admin/includes/media.php' );

    /*echo $uploadedfile = $_FILES['resume']['name'];*/
    

     $uploadedfile = $_FILES['resume'];
      $upload_overrides = array('test_form' => false);
       $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

 $imageurl = $movefile['url'];

    $results = $wpdb->insert($tablejobs, array('first_name' => $_POST['first_name'], 
        'last_name' => $_POST['last_name'],
        'email' => $_POST['email'], 
        'contact_no' => $_POST['contact_no'],
        'job_type_apply' => $_POST['jobs_type'], 
        'jobs_category' => $_POST['jobs_category'], 
        'jobs_locations' => $_POST['jobs_location'],
        'apply_expirence' => $_POST['jobs_expirence'], 
        'apply_resume' => $imageurl,
        'jobs_name' => $_POST['jobs_name'],
        'apply_short_description' => $_POST['apply_short_description'],
        'jobs_board_id' => $_POST['jobs_board_id']));

    if($results){
        echo 'applysucces';
    }

    

    }


exit();


}

 ?>
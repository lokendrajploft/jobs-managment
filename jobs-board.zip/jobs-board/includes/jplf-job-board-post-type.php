<?php

if (!defined('ABSPATH')) {
    exit;
}

function create_job_post_type()
{

    /**
     * Post Type Jobs
     */
    $singular = esc_html__('Job', 'jobs-board');
    $plural   = esc_html__('Jobs', 'jobs-board');

    // Labels
    $labelsjobs = array(
        'name'               => $plural,
        'singular_name'      => $singular,
        'menu_name'          => esc_html__('Job Board', 'jobs-board'),
        'all_items'          => sprintf(esc_html__('All %s', 'jobs-board'), $plural),
        'add_new'            => esc_html__('Add New', 'jobs-board'),
        'add_new_item'       => sprintf(esc_html__('Add %s', 'jobs-board'), $singular),
        'edit_item'          => sprintf(esc_html__('Edit %s', 'jobs-board'), $singular),
        'new_item'           => sprintf(esc_html__('New %s', 'jobs-board'), $singular),
        'view_item'          => sprintf(esc_html__('View %s', 'jobs-board'), $singular),
        'search_items'       => sprintf(esc_html__('Search %s', 'jobs-board'), $plural),
        'not_found'          => sprintf(esc_html__('No %s found', 'jobs-board'), $plural),
        'not_found_in_trash' => sprintf(esc_html__('No %s found in trash', 'jobs-board'), $plural),
        'parent'             => sprintf(esc_html__('Parent %s', 'jobs-board'), $singular),
    );

    // Post Type Arguments
    $argsjobs = array(
        'labels'                => $labelsjobs,
        'hierarchical'          => false,
        'description'           => sprintf(esc_html__('This is where you can create and manage jobs post.', 'jobs-board'), $plural),
        'public'                => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'show_ui'               => true,
        'show_in_nav_menus'     => true,
        'menu_icon'             => 'dashicons-clipboard',
        'capability_type'       => 'post',
        'has_archive'           => true,
        'rewrite'               => array('slug' => 'jobs', 'hierarchical' => true, 'with_front' => false),
        'query_var'             => true,
        'can_export'            => true,
        'show_in_rest'          => true,
        'rest_base'             => 'jobs',
        'rest_controller_class' => 'WP_REST_Posts_Controller',
        'supports'              => array(
            'title',
            'editor',
            'excerpt',
            'author',
            'comments',
            'thumbnail',
            'page-attributes',
            'custom-fields',
        ),
    );

    // Register Custom Post Type -> Jobpost
    register_post_type("jobs", $argsjobs);

    /**
     *
     * Post Type -> Jobs -> Job Category
     */
    $singular = esc_html__('Job Category', 'jobs-board');
    $plural   = esc_html__('Job Categories', 'jobs-board');

    $labelscategory = array(
        'name'                  => $plural,
        'singular_name'         => $singular,
        'menu_name'             => ucwords($plural),
        'all_items'             => sprintf(esc_html__('All %s', 'jobs-board'), $plural),
        'edit_item'             => sprintf(esc_html__('Edit %s', 'jobs-board'), $singular),
        'update_item'           => sprintf(esc_html__('Update %s', 'jobs-board'), $singular),
        'add_new_item'          => sprintf(esc_html__('Add New %s', 'jobs-board'), $singular),
        'new_item_name'         => sprintf(esc_html__('New %s Name', 'jobs-board'), $singular),
        'parent_item'           => sprintf(esc_html__('Parent %s', 'jobs-board'), $singular),
        'parent_item_colon'     => sprintf(esc_html__('Parent %s:', 'jobs-board'), $singular),
        'add_or_remove_items'   => esc_html__('Add or remove', 'jobs-board'),
        'choose_from_most_used' => esc_html__('Choose from most used', 'jobs-board'),
        'search_items'          => sprintf(esc_html__('Search %s', 'jobs-board'), $plural),
        'popular_items'         => sprintf(esc_html__('Popular %s', 'jobs-board'), $plural),
    );

    $argscategory = array(
        'label'                 => $plural,
        'labels'                => $labelscategory,
        'public'                => true,
        'show_in_quick_edit'    => true,
        'rewrite'               => true,
        'show_admin_column'     => true,
        'hierarchical'          => true,
        'query_var'             => true,
        'rewrite'               => array(
            'slug'         => 'job-category',
            'hierarchical' => true,
            'with_front'   => false,
        ),
        'show_in_rest'          => true,
        'rest_base'             => 'job_category',
        'rest_controller_class' => 'WP_REST_Terms_Controller',
    );

    // Register Job Categry Taxonomy
    register_taxonomy(
        "job Category", array('jobs'), $argscategory
    );

    $singular = esc_html__('Job Location', 'jobs-board');
    $plural   = esc_html__('Job Locations', 'jobs-board');

    $labelslocation = array(
        'name'                  => $plural,
        'singular_name'         => $singular,
        'menu_name'             => ucwords($plural),
        'all_items'             => sprintf(esc_html__('All %s', 'jobs-board'), $plural),
        'edit_item'             => sprintf(esc_html__('Edit %s', 'jobs-board'), $singular),
        'update_item'           => sprintf(esc_html__('Update %s', 'jobs-board'), $singular),
        'add_new_item'          => sprintf(esc_html__('Add New %s', 'jobs-board'), $singular),
        'new_item_name'         => sprintf(esc_html__('New %s Name', 'jobs-board'), $singular),
        'parent_item'           => sprintf(esc_html__('Parent %s', 'jobs-board'), $singular),
        'parent_item_colon'     => sprintf(esc_html__('Parent %s:', 'jobs-board'), $singular),
        'add_or_remove_items'   => esc_html__('Add or remove', 'jobs-board'),
        'choose_from_most_used' => esc_html__('Choose from most used', 'jobs-board'),
        'search_items'          => sprintf(esc_html__('Search %s', 'jobs-board'), $plural),
        'popular_items'         => sprintf(esc_html__('Popular %s', 'jobs-board'), $plural),
    );

    $argslocation = array(
        'label'                 => $plural,
        'labels'                => $labelslocation,
        'public'                => true,
        'show_in_quick_edit'    => true,
        'rewrite'               => true,
        'show_admin_column'     => true,
        'hierarchical'          => true,
        'query_var'             => true,
        'rewrite'               => array(
            'slug'         => 'job-location',
            'hierarchical' => true,
            'with_front'   => false,
        ),
        'show_in_rest'          => true,
        'rest_base'             => 'job_location',
        'rest_controller_class' => 'WP_REST_Terms_Controller',
    );

    // Register Job Location Taxonomy
    register_taxonomy(
        "Job Location", array('jobs'), $argslocation
    );

    $singular = esc_html__('Job Types', 'jobs-board');
    $plural   = esc_html__('Job Types', 'jobs-board');

    $labelsjobstype = array(
        'name'                  => $plural,
        'singular_name'         => $singular,
        'menu_name'             => ucwords($plural),
        'all_items'             => sprintf(esc_html__('All %s', 'jobs-board'), $plural),
        'edit_item'             => sprintf(esc_html__('Edit %s', 'jobs-board'), $singular),
        'update_item'           => sprintf(esc_html__('Update %s', 'jobs-board'), $singular),
        'add_new_item'          => sprintf(esc_html__('Add New %s', 'jobs-board'), $singular),
        'new_item_name'         => sprintf(esc_html__('New %s Name', 'jobs-board'), $singular),
        'parent_item'           => sprintf(esc_html__('Parent %s', 'jobs-board'), $singular),
        'parent_item_colon'     => sprintf(esc_html__('Parent %s:', 'jobs-board'), $singular),
        'add_or_remove_items'   => esc_html__('Add or remove', 'jobs-board'),
        'choose_from_most_used' => esc_html__('Choose from most used', 'jobs-board'),
        'search_items'          => sprintf(esc_html__('Search %s', 'jobs-board'), $plural),
        'popular_items'         => sprintf(esc_html__('Popular %s', 'jobs-board'), $plural),
    );

    $argsjobstypes = array(
        'label'                 => $plural,
        'labels'                => $labelsjobstype,
        'public'                => true,
        'show_in_quick_edit'    => true,
        'rewrite'               => true,
        'show_admin_column'     => true,
        'hierarchical'          => true,
        'query_var'             => true,
        'rewrite'               => array(
            'slug'         => 'job-location',
            'hierarchical' => true,
            'with_front'   => false,
        ),
        'show_in_rest'          => true,
        'rest_base'             => 'job_location',
        'rest_controller_class' => 'WP_REST_Terms_Controller',
    );

    // Register Job types Taxonomy
    register_taxonomy(
        "Job Types", array('jobs'), $argsjobstypes
    );

}

add_action('init', 'create_job_post_type');

<?php if (!defined('ABSPATH')) {
    exit;
}?>
<div class="container">
    <h2>
        <?php esc_html_e('Shortcode', 'jobs-board');?>
    </h2>
</div>
<div class="container tab-general-details-jobs" id="general_jobs_board_tab" style="margin-top:20px;">
    <ul class="nav nav-pills">
        <!-- <li class="active">
            <a data-toggle="tab" href="#1a">
                <?php echo esc_html__('General details', 'jobs-board'); ?>
            </a>
        </li> -->
        <!--  <li>
            <a data-toggle="tab" href="#2a">
                <?php echo esc_html__('Email Notifications', 'jobs-board'); ?>
            </a>
        </li>  -->
        <li class="active">
            <a data-toggle="tab" href="#3a">
                <?php echo esc_html__('How can use', 'jobs-board'); ?>
            </a>
        </li>
        
    </ul>
    <div class="tab-content clearfix">
        <!-- <div class="tab-pane active" id="1a">
            
    <div class="wrap">
       
    </div> 
        </div> -->
       <!--  <div class="tab-pane" id="2a">
            Email Nottification Section



        </div>
 -->
                <div class="tab-pane active" id="3a">
            <div class="jplf-section-group">
        
        <div class="col-md-12">
        	<p>jobs board shortcodes are a powerful feature to do cool stuff with little effort. You can do pretty much anything with them. With shortcodes, and Get our Jobs Requirment Listing on show front end page.</p>

        	<p>If you want to List a Jobs board, you have to simply type in the following shortcode:</p>
            <div class="jplf-preview-url">
                <?php echo esc_html__('[jobsboard-list]', 'jobs-board'); ?>
            </div>
            <p>If you want to List a Jobs board, you have to simply type in the following Function code:</p>
            <div class="jplf-preview-url">
            <?php echo esc_html__('jplf_jobs_board_posts_shortcode(); 
                ', 'jobs-board'); ?>
            </div>
        </div>
    </div>
        </div>
        
    </div>
</div>

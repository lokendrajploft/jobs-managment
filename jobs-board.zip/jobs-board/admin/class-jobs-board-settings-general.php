<?php 
if (!defined('ABSPATH')) {
    exit;
    /*accessed directly */
}

class Jobs_Board_Settings_General{



}

 ?>
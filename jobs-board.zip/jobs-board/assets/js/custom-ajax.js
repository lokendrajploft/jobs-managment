/*ajax for applicant user form*/
jQuery(function($) {
    $('.applyjobs_form').on('submit', function(e) {
        e.preventDefault();
        var form = $(this);
        var jobid = $('input[name="jobs_board_id"]').val();
        var formdata = new FormData($(this)[0]);
        formdata.append('action', 'applicant_emp_form_action');
        $.ajax({
            type: 'POST',
            cache: false,
            contentType: false,
            processData: false,
            url: ajaxurl,
            data: formdata,
            success: function(data) {
                if (data == 'applysucces') {
                    $('.success').css('display', 'block');

                    $('.applied_already').css('display', 'none');
                    $('.success').html('You are successfully applied for jobs');

                    
                    setTimeout(function() {
                        $('input[type="text"],input[type="file"],input[type="email"], textarea, select', form).val('');
                    }, 3000);
                    setTimeout(function() {
                        $('.modal').modal('hide');
                    }, 5000);
                } else if (data == 'applied') {
                    $('.applied_already').css('display', 'block');
                    $('.success').css('display', 'none');
                    $('.applied_already').html('You have already applied this jobs!');
                                        $('input[type="text"],input[type="file"],input[type="email"], textarea, select', form).val('');
                    setTimeout(function() {
                        $('input[type="text"],input[type="file"],input[type="email"], textarea, select', form).val('');
                    }, 3000);
                    setTimeout(function() {
                        $('.modal').modal('hide');
                    }, 5000);
                } else {
                    $('.applied_already').css('display', 'block');
                    $('.applied_already').html('Something error! please try Again!');
                    setTimeout(function() {
                        $('.modal').modal('hide');
                    }, 5000);
                }
            }
        });
    });
});
$(document).on("change", '.resume_applicant', function(e) {
    var fileName = $(this).val();
    var idxDot = fileName.lastIndexOf(".") + 1;
    var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
    if (extFile == "pdf" || extFile == "docx" || extFile == "doc") {} else {
        $('.errorcv').css('display', 'block');
        $('.errorcv').html('Only docs/doc and pdf files are allowed!');
        $(".resume_applicant").val('');
    }
});
$(function () {
        $(".apply_jobs").click(function (e) {

            var jobid = $(this).attr('data-jobid');
            $("#"+jobid).modal('show');
            
        });
    });


<?php if (!defined('ABSPATH')) {exit;}

class jobs_board_post_meta_init
{

    public static function init()
    {
        $class = __CLASS__;
        new $class;
    }

    public function __construct()
    {

        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/add-jobs-post-meta-class.php';

        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));

        add_action('jplf_save_jobsboard_meta', array('jplf_jobs_board_post_meta', 'jplf_save_jobsboard_meta'), 30);

        add_action('save_post', array($this, 'save_meta_boxes'));

    }

    public function add_meta_boxes()
    {

        add_meta_box('jobs-board-post_options', esc_html__('Job company data', 'jobs-board'), array('jplf_jobs_board_post_meta', 'jobs_post_meta_output_field'), 'jobs', 'normal');

    }

    /*save post meta data*/

    public function save_meta_boxes($post_id)
    {

        // Check if nonce is set.
        if (null == filter_input(INPUT_POST, 'jplf_job_board_meta_box_nonce')) {
            return;
        }

        // Verify that the nonce is valid.
        check_admin_referer('jplf_jobs_board_meta_box', 'jplf_job_board_meta_box_nonce');

        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check the user's permissions.
        if (null != filter_input(INPUT_POST, 'post_type') && 'page' == filter_input(INPUT_POST, 'post_type')) {
            if (!current_user_can('edit_page', $post_id)) {
                return;
            }
        } else {
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
        }

        do_action('jplf_save_jobsboard_meta', $post_id);
    }

}

new jobs_board_post_meta_init();

add_action('plugins_loaded', array('jobs_board_post_meta_init', 'init'));
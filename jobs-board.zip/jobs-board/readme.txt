=== Woocommerce Order Quantity Control Min Max ===

Contributors: Jploft
Donate link: http://jploft.in
Tags: jobs, jobs-board, job listing, jobs applicants, shortcode, job list jobs managment , job managment, jobs post type, job post
Requires at least: 5.8
Tested up to: 5.7
License: GPLv3 
License URI: http://www.gnu.org/licenses/gpl-3.0.html



== Description ==
[Woocommerce Order Quantity Control Min Max](https://#) plugin allows you to control  
 create a Job Board on your website for job listing.



== Installation ==

1. Go to the Add New plugins screen in your WordPress Dashboard
1. Click the upload tab
1. Browse for the plugin file (jobs-board) on your computer
1. Click "Install Now" and then hit the activate button 






